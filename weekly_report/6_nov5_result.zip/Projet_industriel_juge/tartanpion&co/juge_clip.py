import torch
from PIL import Image
from transformers import AutoProcessor, AutoModelForZeroShotImageClassification

# ==============================
# 1. Chargement du modèle CLIP
# ==============================
MODEL_NAME = "openai/clip-vit-base-patch32"

print("Chargement du modèle CLIP...")
device = "cpu"

processor = AutoProcessor.from_pretrained(MODEL_NAME)
model = AutoModelForZeroShotImageClassification.from_pretrained(MODEL_NAME).to(device)

print(f"Modèle chargé. (Device: {device})")


# ==============================
# 2. Fonction de classification (Modifiée)
# ==============================
def judge_image(image_path, criteria, threshold=0.7):
    """
    Juge une image en vérifiant la conformité pour CHAQUE critère séparément.
    """
    try:
        image = Image.open(image_path).convert("RGB")
    except Exception as e:
        return {"error": f"Impossible de charger l'image: {e}"}

    results = []

    # Boucler sur chaque critère pour l'évaluer individuellement
    for criterion in criteria:
        
        # On crée une classification binaire : le critère vs un label négatif générique.
        # Cela force le modèle à répondre "Oui, c'est [critère]" ou "Non, c'est [autre chose]".
        labels = [criterion, "a different or unrelated image"] 

        inputs = processor(
            text=labels,
            images=image,
            return_tensors="pt",
            padding=True
        ).to(device)

        # Inference
        with torch.no_grad():
            outputs = model(**inputs)

        logits = outputs.logits_per_image[0]
        # Softmax sur la paire [positif, negatif]
        probs = logits.softmax(dim=-1)

        # Le score du critère positif (le premier label)
        positive_score = float(probs[0])

        # Vérifier la conformité pour CE critère
        is_compliant = positive_score >= threshold

        results.append({
            "criterion": criterion,
            "score": positive_score, # Score de confiance pour le critère positif
            "compliant": is_compliant
        })

    # Calculer la conformité globale (True seulement si TOUS les critères sont conformes)
    all_compliant = all(res["compliant"] for res in results)

    return {
        "image": image_path,
        "criteria_results": results,
        "all_compliant": all_compliant
    }

# ==============================
# 3. EXEMPLE d'utilisation (Modifié)
# ==============================
if __name__ == "__main__":
    # Assurez-vous que cette image existe
    IMAGE = "unnamed4.jpg" 

    # Renommé 'positive' en 'criteria' pour plus de clarté
    criteria = [
        "chibi-style image",
        "cartoon character viewed from above",
        "stylized head viewed from above"
    ]
    
    # Un seuil de 70% pour chaque critère peut être élevé.
    # Un seuil de 0.5 (50%) est souvent un bon point de départ pour une classification binaire.
    # Ajustez-le en fonction de vos tests.
    result = judge_image(IMAGE, criteria, threshold=0.5)

    print("\n=== Résultat ===")
    
    if result.get("error"):
        print(f"Erreur : {result['error']}")
    else:
        print(f"Image : {result['image']}")
        print("\n--- Vérification des Critères ---")
        
        for res in result["criteria_results"]:
            status = "✅ Conforme" if res["compliant"] else "❌ Non conforme"
            # Utilise :<50 pour aligner le texte
            print(f"{res['criterion']:<50} -> {res['score']*100:.2f}% ({status})")

        print("\n--- Verdict Final ---")
        verdict = "✅ Totalement conforme" if result["all_compliant"] else "❌ Non conforme (au moins un critère a échoué)"
        print(verdict)