import torch
from PIL import Image
from transformers import CLIPProcessor, CLIPModel

print("Chargement du modèle CLIP...")
model_id = "openai/clip-vit-base-patch32"
model = CLIPModel.from_pretrained(model_id)
processor = CLIPProcessor.from_pretrained(model_id)
model.eval()

# --- Catégories ---
categories_cumulatives = {
    "style": [
        "simple cartoon style",
        "minimalist design",
        "cel-shaded",
        "vector art style",
        "clean lines",
        "no shadows"
    ],
    "traits": [
        "very thick black outlines",
        "cute chibi proportions",
        "large round head",
        "detached isolated head"
    ]
}

categories_exclusives = {
    "view": [
        "top down view",
        "front view",
        "side view",
        "three-quarter view",
        "back view"
    ],
    "background": [
        "no background",
        "plain color background",
        "complex detailed background"
    ]
}

# --- Image à tester ---
image_path = "knightHead_sans_fond_redim.png"
image = Image.open(image_path)

# --- Préparation ---
# Fusionner tous les textes
all_texts = [t for cat in {**categories_cumulatives, **categories_exclusives}.values() for t in cat]
inputs = processor(text=all_texts, images=image, return_tensors="pt", padding=True)

with torch.no_grad():
    outputs = model(**inputs)
    logits = outputs.logits_per_image[0]
# # --- Normalisation sur [0,1] ---
# logit_scale = model.logit_scale.exp().item()
# scores_norm = (logits + logit_scale) / (2 * logit_scale)
# scores_norm = scores_norm.tolist()

# --- Analyse par catégorie ---
offset = 0
results = {}

print("\n--- CATÉGORIES CUMULATIVES ---")
for cat, crits in categories_cumulatives.items():
    n = len(crits)
    # subscores = scores_norm[offset:offset+n]
    subscores = logits[offset:offset+n].softmax(dim=0).tolist()
    offset += n
    mean_score = sum(subscores) / n
    results[cat] = mean_score
    print(f"\n[{cat.upper()}]")
    for c, s in zip(crits, subscores):
        print(f"  [{s:.3f}] {c}")
    print(f"→ Score moyen catégorie '{cat}': {mean_score:.3f}")

print("\n--- CATÉGORIES EXCLUSIVES ---")
for cat, crits in categories_exclusives.items():
    n = len(crits)
    # subscores = scores_norm[offset:offset+n]
    subscores = logits[offset:offset+n].softmax(dim=0).tolist()
    # probs = logits_per_image.softmax(dim=1)
    offset += n
    best_idx = subscores.index(max(subscores))
    best_label = crits[best_idx]
    best_score = subscores[best_idx]
    results[cat] = (best_label, best_score)
    print(f"\n[{cat.upper()}]")
    for c, s in zip(crits, subscores):
        print(f"  [{s:.3f}] {c}")
    print(f"→ Choix dominant : '{best_label}' ({best_score:.3f})")

# --- Synthèse finale ---
print("\n=== SYNTHÈSE ===")
for cat, val in results.items():
    if isinstance(val, tuple):
        print(f"{cat}: {val[0]} ({val[1]:.3f})")
    else:
        print(f"{cat}: {val:.3f}")
