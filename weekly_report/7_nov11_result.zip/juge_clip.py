import torch
from PIL import Image
from transformers import CLIPProcessor, CLIPModel

# Étape 1 : Charger le modèle et le processeur CLIP
# (Cela peut prendre quelques secondes au premier lancement pour télécharger le modèle)
print("Chargement du modèle CLIP...")
model_id = "openai/clip-vit-base-patch32"
model = CLIPModel.from_pretrained(model_id)
processor = CLIPProcessor.from_pretrained(model_id)

# Mettre le modèle en mode "évaluation" (important)
model.eval()

# Étape 2 : Préparer vos "labels" (Le cœur de votre juge)
# C'est ici que vous décrivez ce qui est "bon" et ce qui est "mauvais"
# Soyez aussi descriptif que possible.
text_labels = [
    "simple cartoon style, minimalist design, very thick black outlines, cel-shaded, cute chibi proportions, large round head, no background, transparent background, vector art style, clean lines, no shadows, game asset, character portrait, centered composition, detached isolated head, top down view",  # ✅ BON
    "realistic style, complex shading, thin outlines, textured, detailed lighting, background, perspective view, semi-realistic rendering",  # ❌ MAUVAIS
    "side view or front view head, not top down, sketchy lines, messy outlines, inconsistent proportions"  # ❌ MAUVAIS
]

# Étape 3 : Charger l'image que vous voulez tester
try:
    image_path = "knightHead_sans_fond_redim.png"
    image = Image.open(image_path)
except FileNotFoundError:
    print(f"Erreur : L'image '{image_path}' n'a pas été trouvée.")
    print("Veuillez remplacer le chemin par une image valide.")
    exit()

print(f"Analyse de l'image : {image_path}")

# Étape 4 : Traitement et Calcul des scores
# Le "processeur" prépare l'image et le texte pour le modèle
inputs = processor(
    text=text_labels,
    images=image,
    return_tensors="pt", # Retourne des tenseurs PyTorch
    padding=True
)

# Désactiver le calcul du gradient (plus rapide et moins de mémoire)
with torch.no_grad():
    # On passe les données au modèle
    outputs = model(**inputs)

# Les "logits" sont les scores bruts.
# On récupère les scores de similarité entre l'image et CHAQUE texte
logits_per_image = outputs.logits_per_image

# On utilise "softmax" pour convertir ces scores en pourcentages (probabilités)
probs = logits_per_image.softmax(dim=1)

print("\n--- RÉSULTATS DU JUGEMENT ---")

# Étape 5 : Afficher les résultats
# On associe chaque label à son score en pourcentage
scores = probs[0].tolist() # On prend la première (et unique) image
for i, label in enumerate(text_labels):
    score_percent = scores[i] * 100
    print(f"[{score_percent:6.2f} %] - {label}")

# Logique de décision pour votre script
meilleur_score_index = scores.index(max(scores))
if meilleur_score_index == 0: # Si le 1er label ("parfaitement ronde") a gagné
    print("\nVERDICT : ✅ L'image semble correspondre à votre critère principal.")
else:
    print(f"\nVERDICT : ❌ L'image ressemble plus à : '{text_labels[meilleur_score_index]}'")