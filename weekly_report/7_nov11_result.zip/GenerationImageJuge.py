import torch
from PIL import Image
from transformers import CLIPProcessor, AutoModelForZeroShotImageClassification # Changement de l'import pour la compatibilité
import requests
from io import BytesIO

# ==============================
# 0. Configuration de l'API d'image
# ==============================
# URL de Picsum pour une image aléatoire de 512x512 pixels
RANDOM_IMAGE_URL = "https://picsum.photos/512/512"
# Chemin pour sauvegarder temporairement l'image téléchargée
TEMP_IMAGE_PATH = "temp_random_image.jpg"

# ==============================
# 1. Chargement du modèle CLIP
# ==============================
MODEL_NAME = "openai/clip-vit-base-patch32"

print("Chargement du modèle CLIP...")
# Détection automatique du device (GPU si disponible, sinon CPU)
device = "cuda" if torch.cuda.is_available() else "cpu"

# Utilisation de CLIPProcessor pour contourner les problèmes potentiels avec AutoProcessor
processor = CLIPProcessor.from_pretrained(MODEL_NAME)
model = AutoModelForZeroShotImageClassification.from_pretrained(MODEL_NAME).to(device)

print(f"Modèle chargé. (Device: {device})")


# ==============================
# 2. Fonction de classification
# ==============================
def judge_image(image_source, criteria, threshold=0.5):
    """
    Juge une image en vérifiant la conformité pour CHAQUE critère séparément.
    Retourne l'objet image pour l'affichage.
    """
    try:
        # Téléchargement de l'image depuis l'URL
        print(f"Téléchargement de l'image depuis: {image_source}")
        response = requests.get(image_source)
        response.raise_for_status() # Lève une exception pour les erreurs HTTP

        # Charger l'image en mémoire (via BytesIO)
        image = Image.open(BytesIO(response.content)).convert("RGB")
    except requests.exceptions.RequestException as e:
        return {"error": f"Erreur de réseau ou HTTP lors du téléchargement: {e}"}, None
    except Exception as e:
        return {"error": f"Impossible de charger/ouvrir l'image: {e}"}, None

    results = []

    # Boucler sur chaque critère pour l'évaluer individuellement
    for criterion in criteria:

        labels = [criterion, "a different or unrelated image"]

        inputs = processor(
            text=labels,
            images=image,
            return_tensors="pt",
            padding=True
        ).to(device)

        # Inference
        with torch.no_grad():
            outputs = model(**inputs)

        logits = outputs.logits_per_image[0]
        probs = logits.softmax(dim=-1)

        positive_score = float(probs[0])
        is_compliant = positive_score >= threshold

        results.append({
            "criterion": criterion,
            "score": positive_score,
            "compliant": is_compliant
        })

    all_compliant = all(res["compliant"] for res in results)

    result_data = {
        "image": image_source,
        "criteria_results": results,
        "all_compliant": all_compliant
    }

    # Retourne les données de résultat ET l'objet Image
    return result_data, image

# ==============================
# 3. EXEMPLE d'utilisation
# ==============================
if __name__ == "__main__":
    IMAGE_SOURCE = RANDOM_IMAGE_URL

    criteria = [
        "a photograph of a natural landscape",
        "a picture taken outdoors",
        "an image containing trees or water",
    ]

    result, image_object = judge_image(IMAGE_SOURCE, criteria, threshold=0.5)

    print("\n=== Résultat ===")

    if result.get("error"):
        print(f"Erreur : {result['error']}")
    else:
        print(f"Image : {result['image']} (L'image est nouvelle à chaque exécution)")
        print(f"Seuil de conformité : {0.5*100:.0f}%")
        print("\n--- Vérification des Critères ---")

        for res in result["criteria_results"]:
            status = "✅ Conforme" if res["compliant"] else "❌ Non conforme"
            print(f"{res['criterion']:<50} -> {res['score']*100:.2f}% ({status})")

        print("\n--- Verdict Final ---")
        verdict = "✅ Totalement conforme" if result["all_compliant"] else "❌ Non conforme (au moins un critère a échoué)"
        print(verdict)

        print(f"\n--- Affichage de l'image ---")
        try:
            # Sauvegarder l'image pour un affichage stable
            image_object.save(TEMP_IMAGE_PATH)
            print(f"Image sauvegardée temporairement sous : {TEMP_IMAGE_PATH}")
            # Ouvrir l'image (cela ouvrira le programme d'affichage par défaut de votre OS)
            image_object.show()
            print("L'image a été ouverte dans une nouvelle fenêtre.")
        except Exception as e:
            print(f"Erreur lors de l'affichage de l'image (Pillow/OS) : {e}")