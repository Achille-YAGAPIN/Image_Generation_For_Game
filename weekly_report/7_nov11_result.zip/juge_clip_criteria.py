import torch
from PIL import Image
from transformers import CLIPProcessor, CLIPModel

# --- Chargement modèle ---
model_id = "openai/clip-vit-base-patch32"
model = CLIPModel.from_pretrained(model_id)
processor = CLIPProcessor.from_pretrained(model_id)
model.eval()

# --- Image et critères ---
image = Image.open("knightHead_sans_fond_redim.png")

criteria = [
    "simple cartoon style",
    "minimalist design",
    "very thick black outlines",
    "cel-shaded",
    "cute chibi proportions",
    "large round head",
    "no background",
    "transparent background",
    "vector art style",
    "clean lines",
    "no shadows",
    "game asset",
    "character portrait",
    "centered composition",
    "detached isolated head",
    "top down view",
    "blue",
]

# --- Passage dans CLIP ---
inputs = processor(text=criteria, images=image, return_tensors="pt", padding=True)
with torch.no_grad():
    outputs = model(**inputs)

logits = outputs.logits_per_image[0]  # tensor shape [1, N]

# --- Normalisation entre 0 et 1 ---
logit_scale = model.logit_scale.exp().item()
scores_norm = logits / logit_scale
scores_norm = scores_norm.tolist()

# --- Affichage ---
print(f"logit_scale = {logit_scale:.2f}")
print("\n--- Scores normalisés ---")
for c, s in zip(criteria, scores_norm):
    print(f"[{s:.3f}] {c}")

# Exemple de décision
threshold = 0.2
passed = [(c, s) for c, s in zip(criteria, scores_norm) if s >= threshold]
print(f"\n{len(passed)}/{len(criteria)} critères dépassent {threshold:.2f}")
